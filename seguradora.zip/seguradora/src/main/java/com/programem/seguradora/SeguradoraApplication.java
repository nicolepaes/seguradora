package com.programem.seguradora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeguradoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeguradoraApplication.class, args);
	}

}
